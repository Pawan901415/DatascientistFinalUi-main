import React from 'react'

export default function PageNotFound() {
  return (
    <>
    <h2>PageNotFound prod</h2>
    </>
  )
}
