import React from 'react'

export default function ViewFeature() {
  return (
    <>
    <h2>Feature Title</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Bibendum ut tristique et egestas. Ornare arcu dui vivamus arcu felis bibendum ut tristique et.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Bibendum ut tristique et egestas. Ornare arcu dui vivamus arcu felis bibendum ut tristique et.</p>
    </>
  )
}
