import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import '../Styles/FirstFactorAuthStyles.css';
import '@fortawesome/fontawesome-free/css/all.css';


const FirstFactorAuth = ({ onSuccess }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleFirstFactorAuth = async () => {
    try {
      const response = await axios.post(
        "https://usermanagementapiteam4.azurewebsites.net/api/Authentication/login",
        {
          username: username,
          password: password,
        }
      );

      if (response.data.status === "Success") {
        onSuccess(username);
        
      } else {
        // Handle authentication failure
        console.log("err");
      }
    } catch (error) {
      // Handle network or other errors
      console.log("err1");
    }
  };

  
    
  return (
    <>
      <div className="form_bg">
	      <div  className="container" >
	        <div className="row">
	          <div className="col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6">
		          <form className="form_horizontal"> 
			          <div className="form_icon"><i class="fa fa-user" style={{ color: 'lightgrey' }}></i></div>
                  {/* <h3 className="title" style={{ color: 'black' }}>Please Login</h3> */}
                  <br/>
                  <div className="form-group">
                  <span className="input-icon"><i class="fa fa-user"></i></span>
                    <input
                      className="form-control"
                      type="text"
                      placeholder=" Username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                  <span class="input-icon"><i class="fa fa-lock"></i></span>
                    <input
                      class="form-control"
                      type="password"
                      placeholder=" Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>

                  <button className="btn signin" onClick={handleFirstFactorAuth}>Login</button>
                  {/* <ul className="form-options">
                    <li><a href="#">Forgot username/password</a></li>
                    <li><a href="#">Create New Account<i class="fa fa-arrow-right"></i></a></li>
                  </ul> */}
                </form>
              </div>
            </div>
          </div>     
      </div>
    </>
  );
};

export default FirstFactorAuth;
