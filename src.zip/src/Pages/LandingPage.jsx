import React from 'react';
import Header from '../Components/Header';
import Info from '../Components/Info';
import Navbar from "../Components/Navbar";
const LandingPage = () => {
 
  
  return (
  <>
    <Navbar />
    <Header/>
    <Info/>    
  </>
  );
};
 
export default LandingPage;